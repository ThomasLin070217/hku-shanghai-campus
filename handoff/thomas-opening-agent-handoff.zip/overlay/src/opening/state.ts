import type{OpeningEvent,OpeningStage,OpeningState}from'./contracts';
/** Pure, immutable beat reducer for the Thomas opening: bus→exit→B5 errand→B6 laptop→return→incident→alert→B4. Invalid or repeated events return the identical state object. */
const STAGES:readonly OpeningStage[]=['bus','to_b5','to_b6','return_b5','incident','to_b4','complete'];
type FlagKey='invitation_read'|'laptop_acquired'|'campus_alert_triggered'|'alert_read';
interface Rule{from:OpeningStage;to:OpeningStage;log:string;flag?:FlagKey;requires?:FlagKey}
// Order of values defines the canonical event log; reach_b4 logs the internal beat, never chapter_01_completed.
const RULES:Record<OpeningEvent,Rule>={
 read_invitation:{from:'bus',to:'bus',log:'invitation_read',flag:'invitation_read'},
 exit_bus:{from:'bus',to:'to_b5',log:'opening.bus_exited',requires:'invitation_read'},
 accept_errand:{from:'to_b5',to:'to_b6',log:'opening.laptop_requested'},
 take_laptop:{from:'to_b6',to:'return_b5',log:'laptop_acquired',flag:'laptop_acquired'},
 return_b5:{from:'return_b5',to:'incident',log:'campus_alert_triggered',flag:'campus_alert_triggered'},
 read_alert:{from:'incident',to:'to_b4',log:'opening.alert_acknowledged',flag:'alert_read'},
 reach_b4:{from:'to_b4',to:'complete',log:'opening.building4_reached'},
};
const LOGS=Object.values(RULES).map(r=>r.log);
const BEATS_TO_STAGE=[0,2,3,4,5,6,7];
const FLAGS:FlagKey[]=['invitation_read','laptop_acquired','campus_alert_triggered','alert_read'];
export function createOpeningState():OpeningState{
 return{schemaVersion:1,stage:'bus',invitation_read:false,laptop_acquired:false,campus_alert_triggered:false,alert_read:false,events:[],elapsedSeconds:0};
}
export function reduceOpening(state:OpeningState,event:OpeningEvent):OpeningState{
 if(!Object.prototype.hasOwnProperty.call(RULES,event))return state;
 const rule=RULES[event];
 if(!rule||state.stage!==rule.from)return state;
 if(rule.requires&&!state[rule.requires])return state;
 if(rule.flag&&state[rule.flag])return state;
 if(state.events.includes(rule.log))return state;
 const next:OpeningState={...state,stage:rule.to,events:[...state.events,rule.log]};
 if(rule.flag)next[rule.flag]=true;
 return next;
}
/** Strict validator: stage/flag monotonicity, finite elapsed, and events exactly the canonical prefix for the stage (whitelist + unique + ordered). */
export function validOpeningState(raw:unknown):OpeningState|null{
 if(!raw||typeof raw!=='object')return null;
 const r=raw as Record<string,unknown>;
 if(r.schemaVersion!==1)return null;
 if(typeof r.stage!=='string'||!STAGES.includes(r.stage as OpeningStage))return null;
 if(!FLAGS.every(k=>typeof r[k]==='boolean'))return null;
 const stage=r.stage as OpeningStage,i=STAGES.indexOf(stage);
 const invitation=r.invitation_read===true,laptop=r.laptop_acquired===true,alerted=r.campus_alert_triggered===true,acknowledged=r.alert_read===true;
 if(i>=1&&!invitation)return null;
 if(laptop!==(i>=3)||alerted!==(i>=4)||acknowledged!==(i>=5))return null;
 if(!Number.isFinite(r.elapsedSeconds)||(r.elapsedSeconds as number)<0)return null;
 if(!Array.isArray(r.events))return null;
 const events=r.events as unknown[];
 const n=i===0?(invitation?1:0):BEATS_TO_STAGE[i];
 if(events.length!==n)return null;
 for(let k=0;k<n;k++)if(events[k]!==LOGS[k])return null;
 return{schemaVersion:1,stage,invitation_read:invitation,laptop_acquired:laptop,campus_alert_triggered:alerted,alert_read:acknowledged,events:[...(events as string[])],elapsedSeconds:r.elapsedSeconds as number};
}
