import type{CampusGame}from'../exploration/game';
import{readSettings,type Settings}from'../gameplay/save';
import{ITEMS}from'../items/definitions';
import type{ItemStack}from'../items/inventory';
import type{OpeningSave,OpeningState}from'./contracts';
import{validOpeningState}from'./state';
import{OPENING_WORLD_REVISION}from'./spatialLayout';
/** Separate namespace from the survey save (hku.digital-survey.v1); the shared parser is untouched. */
export const OPENING_SAVE_KEY='hku.opening.v1';
const MACBOOK='macbook-air-13-silver';
const finite=(x:unknown):x is number=>typeof x==='number'&&Number.isFinite(x);
export function parseOpeningSave(raw:unknown):OpeningSave|null{
 if(!raw||typeof raw!=='object')return null;
 const r=raw as Record<string,unknown>;
 if(r.version!==1||r.mode!=='opening')return null;
 if(r.worldRevision!==OPENING_WORLD_REVISION||!finite(r.savedAt))return null;
 const story=validOpeningState(r.story);if(!story)return null;
 if(!Array.isArray(r.position)||r.position.length!==3||!r.position.every(finite))return null;
 if(!finite(r.yaw)||!finite(r.pitch))return null;
 if(r.view!=='first'&&r.view!=='third')return null;
 const hotbar=r.selectedHotbar;
 if(!Number.isInteger(hotbar)||(hotbar as number)<0||(hotbar as number)>8)return null;
 if(!Array.isArray(r.slots)||r.slots.length!==36)return null;
 const ids=new Set<string>(),slots:(ItemStack|null)[]=[];let mac=0;
 for(const item of r.slots as(unknown)[]){
  if(item===null){slots.push(null);continue;}
  if(!item||typeof item!=='object')return null;
  const it=item as Partial<ItemStack>;
  const def=typeof it.itemId==='string'?ITEMS[it.itemId]:undefined;
  if(!def||typeof it.instanceId!=='string'||!it.instanceId||ids.has(it.instanceId)||!Number.isInteger(it.count)||(it.count as number)<1||(it.count as number)>def.maxStack)return null;
  if(it.itemId===MACBOOK)mac++;
  ids.add(it.instanceId);slots.push({itemId:it.itemId,instanceId:it.instanceId,count:it.count as number});
 }
 // Exactly one MacBook iff the laptop beat fired; a fully empty backpack is a legitimate pre-laptop bus save.
 if(story.laptop_acquired?mac!==1:mac!==0)return null;
 return{version:1,mode:'opening',worldRevision:OPENING_WORLD_REVISION,savedAt:r.savedAt as number,position:[(r.position as number[])[0],(r.position as number[])[1],(r.position as number[])[2]] as [number,number,number],yaw:r.yaw as number,pitch:r.pitch as number,view:r.view,slots,selectedHotbar:hotbar as number,story,settings:readSettings(r.settings)};
}
export function captureOpeningSave(g:CampusGame,story:OpeningState,settings:Settings,position?:[number,number,number]):OpeningSave{
 // Inventory seeds the survey MacBook at boot; while story.laptop_acquired is false it must not leak into the opening save. g is never mutated.
 const slots=g.inventory.slots.map(s=>!s?null:story.laptop_acquired||s.itemId!==MACBOOK?{...s}:null);
 return{version:1,mode:'opening',worldRevision:OPENING_WORLD_REVISION,savedAt:Date.now(),position:position?[position[0],position[1],position[2]]:g.body.position.toArray() as [number,number,number],yaw:g.yaw,pitch:g.pitch,view:g.view,slots,selectedHotbar:g.inventory.selectedHotbar,story:{...story,events:[...story.events]},settings:{...settings}};
}
